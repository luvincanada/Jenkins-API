#!/bin/bash

## REST API USER GUIDE V3 2.3.1-4  check Content Filter for Logging server

SWITCH_IP="172.31.56.79"

SYS="restconf/data/running/openconfig-system"


echo "guide V1.3 2.3.1 NTP enable disable"

curl --user ADMIN:ADMIN -H "Content-Type: application/yang-data+json" -X PUT -d '{"config":{"enabled":"true","ntp-source-address":"192.168.2.2"}}' http://$SWITCH_IP:8538/$SYS/ntp/config -v


sleep 2
echo "Get NTP"
curl --user ADMIN:ADMIN http://$SWITCH_IP:8538/$SYS/ntp/servers/server=192.168.2.2/config -v

sleep 2
echo "V3 2.3.2 create NTP"
curl --user ADMIN:ADMIN -H "Content-Type: application/yang-data+json" -X POST -d '{"address":"192.168.2.2"}' http://$SWITCH_IP:8538/$SYS/ntp/servers -v

sleep 2
echo "V3 GET NTP"
curl --user ADMIN:ADMIN http://$SWITCH_IP:8538/$SYS/ntp/servers  -v

sleep 2
echo "V3 2.3.3 configure prefered NTP server"
curl --user ADMIN:ADMIN -H "Content-Type: application/yang-data+json" -X PATCH -d '{"address":"192.168.2.2","config":{"prefer":"true"}}' http://$SWITCH_IP:8538/$SYS/ntp/servers/server=192.168.2.2/config/prefer -v

sleep 2
echo " Get prefered ntp"
curl --user ADMIN:ADMIN http://$SWITCH_IP:8538/$SYS/ntp/servers/server=192.168.2.2/config/prefer -v

sleep 2
echo "V3 2.3.4 Delete NTP"
curl --user ADMIN:ADMIN -H "Content-Type: application/yang-data+json" -X DELETE http://$SWITCH_IP:8538/$SYS/ntp/servers/server=192.168.2.2 -v

sleep 2
echo "GET NTP after delete"
curl --user ADMIN:ADMIN http://$SWITCH_IP:8538/$SYS/ntp/servers -v


